library(indicspecies)

VAR = c('FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','FL','SA','SA','SA','SA','SA','SA','SA','SA','SA')


DAT = read.delim('Thau_SA_9_FL_18_mod.txt', row.names = 1)
tDAT = t(DAT[,1:27])

AssFun = multipatt(x = as.data.frame(tDAT), cluster = VAR, func = 'r.g', duleg = T)$sign
AssFun2 = data.frame(COG = row.names(AssFun), AssFun)
AssFun2$Function = DAT$Function
write.table(x = AssFun2, file = 'AssociatedFunctions.txt', append = F, quote = F, sep = "\t", row.names = F, col.names = T)


tDat_mod = ifelse(tDAT > 0, 1, 0)
AssFun_mod = multipatt(x = as.data.frame(tDat_mod), cluster = VAR, func = 'r.g', duleg = T)$sign
AssFun2_mod = data.frame(COG = row.names(AssFun_mod), AssFun_mod)
AssFun2_mod$Function = DAT$Function
write.table(x = AssFun2_mod, file = 'AssociatedFunctions_mod.txt', append = F, quote = F, sep = "\t", row.names = F, col.names = T)




eg_logical <- c(T, T, T, F, F) 
eg_integer <- c(1L, 6L, 1L, 5L, 4L)
eg_numeric <- c(0, 2.3, 2.45, 2.99, -1.1)
eg_character <- c("NSW", "NSW", "ACT", "WA", "WA")
eg_factor <- factor(c("NSW", "NSW", "ACT", "WA", "WA"))


print(eg_character)
print(eg_factor)
levels(eg_factor)


import seaborn as sns

sns.palplot(sns.color_palette("PuBu", 10))


import seaborn as sns
#print(sns.color_palette("Reds", 15))

sns.color_palette("bone", 15)
sns.color_palette("Reds", 15)
sns.color_palette("flare", 15)



sns.color_palette("light:#5A9", 15)


sns.color_palette("Greens", 15)
sns.dark_palette("seagreen")



# Greys, Purples, Blues, Greens, Oranges, Reds
sns.color_palette("Greys", 5)
sns.color_palette("Purples", 5)
sns.color_palette("Blues", 5)
sns.color_palette("Greens", 5)
sns.color_palette("Reds", 5)


sns.color_palette("Purples", 5)


sns.light_palette("red")



sns.color_palette("Cyans", 15)


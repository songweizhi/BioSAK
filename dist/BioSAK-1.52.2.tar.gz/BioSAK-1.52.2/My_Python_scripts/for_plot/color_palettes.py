import seaborn as sns

print(sns.color_palette("Paired"))


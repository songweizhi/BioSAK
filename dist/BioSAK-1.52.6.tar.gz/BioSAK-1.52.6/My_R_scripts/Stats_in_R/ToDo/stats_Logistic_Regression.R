
################################# stat_Logistic_Regression #################################

# https://stats.idre.ucla.edu/r/dae/logit-regression/

# https://www.datacamp.com/community/tutorials/logistic-regression-R

# https://www.r-bloggers.com/how-to-perform-a-logistic-regression-in-r/












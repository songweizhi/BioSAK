import os
import scrapy


wd  = '/Users/songweizhi/Desktop/scrapy_demo'

os.chdir(wd)



#os.system('scrapy startproject tutorial')


os.system('cd /Users/songweizhi/Desktop/scrapy_demo/tutorial')
os.system('scrapy crawl quotes')


# os.system(' ')




# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')
# os.system(' ')



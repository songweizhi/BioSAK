install.packages("igraph")
install.packages("micropan")
library(igraph)
library(micropan)
?micropan

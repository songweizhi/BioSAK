__author__ = 'weizhisong'

import matplotlib.pyplot as plt
import numpy as np
import pylab

x = np.array([0,1,2,3,4])
y = np.array([3,5,4,6,7])
pylab.scatter(x,y);

plt.show()

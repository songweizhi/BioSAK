##These are my plot examples in R
###Circlize_demo
![](Circlize_demo.png)

###googleVis
![](googleVis.jpg)

###heatmap_plotrix
![](heatmap_plotrix.png)

###heatmap_ploty
![](heatmap_ploty_1.png)

###heatmap_ploty
![](heatmap_ploty_2.png)

###plot_ggplot2
![](plot_ggplot2_1.png)

###plot_ggplot2
![](plot_ggplot2_2.png)

###plot_ggplot2
![](plot_ggplot2_3.png)

###VennDiagram
![](VennDiagram.png)

molecular_weight = 292.24
conc_in_M = 0.45
volume_in_ml = 20

chemical_needed_in_g = (molecular_weight*conc_in_M)/1000*volume_in_ml

print(chemical_needed_in_g)

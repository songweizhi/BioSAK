
+ Tax4Fun2 was developed by Dr Bernd Wemheuer.
+ [This](Tax4Fun2_example_cmds.R) is a short R script showing how it can be installed and executed for functional prediction.
+ https://environmentalmicrobiome.biomedcentral.com/articles/10.1186/s40793-020-00358-7

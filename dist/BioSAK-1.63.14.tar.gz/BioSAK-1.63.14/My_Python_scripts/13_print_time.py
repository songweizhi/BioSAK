from datetime import datetime

current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(current_time)

# About

##Examples to plot in python.

####2D_line
   ![2D_line](2D_line.png)

####2D_scatter_1
   ![2D_scatter_1](2D_scatter_1.png)

####2D_scatter_2_dot_size
   ![2D_scatter_2_dot_size](2D_scatter_2_dot_size.png)

####2D_scatter_3_groups
   ![2D_scatter_3_groups](2D_scatter_3_groups.png)

####Density_plot_gaussian_kde
   ![Density_plot_gaussian_kde](Density_plot_gaussian_kde.png)

####Distribution_plot_4_in_1
   ![Distribution_plot_4_in_1](Distribution_plot_4_in_1.png)

####Heatmap_in_ploty
   ![Heatmap_in_ploty](Heatmap_in_ploty.png)

####Add_text_in_matplotlib
   ![Add_text_in_matplotlib](Add_text_in_matplotlib.png)

####3D_scatter
   ![3D_scatter](3D_scatter.png)


#####Useful Links:

1. Plotly Python Library
https://plot.ly/python/

2. Make a Heatmap
http://help.plot.ly/make-a-heatmap/
    
    BioSAK VisGeneFlk -gene gene_01 -gbk input.gbk -len 2000 -fmt pdf
    BioSAK VisGeneFlk -gene gene_01 -gbk input.gbk -len 5000 -scale 300


BioSAK gbk2faa -i MAG.gbk -o MAG.faa
BioSAK gbk2faa -i gbk_dir -o faa_dir -t 6

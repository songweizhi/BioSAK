
# module needed
module load hmmer/3.2.1

# for completed genome
BioSAK get_Pfam_hmms -pfam Pfam-A.hmm -id needed_ids.txt

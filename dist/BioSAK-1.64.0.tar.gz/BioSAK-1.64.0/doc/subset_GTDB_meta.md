
    BioSAK subset_GTDB_meta -meta ar122_metadata_r202.tsv -id gnm_id.txt -out metadata_subset.txt
    BioSAK subset_GTDB_meta -meta bac120_metadata_r202.tsv -id gnm_id.txt -out metadata_subset.txt

# format of gnm_id.txt (one id per line)
GCA_002726655.1
GCA_002728675.1
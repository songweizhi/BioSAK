
    BioSAK Plot_MAG -i MAG_dir -x fa -d ctg_depth.txt 
    BioSAK Plot_MAG -i MAG_dir -x fa -d ctg_depth.txt -sep

# depth file: tab separated, no header
contig_1    30
contig_2    5
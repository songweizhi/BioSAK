BioSAK get_gnm_size -i genome_1.fa
BioSAK get_gnm_size -i refined_MAGs -x fasta 
BioSAK get_gnm_size -i refined_MAGs -x fasta -total

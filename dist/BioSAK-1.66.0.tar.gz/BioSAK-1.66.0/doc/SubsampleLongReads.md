
    BioSAK SubsampleLongReads -i LongReads.fastq -s 5 -o op_dir_5 -fq
    BioSAK SubsampleLongReads -i LongReads.fastq -s 1,5,10 -o op_dir_1-10 -fq
    BioSAK SubsampleLongReads -i LongReads.fastq -s 1,25,50,75 -o op_dir_1-75 -fq

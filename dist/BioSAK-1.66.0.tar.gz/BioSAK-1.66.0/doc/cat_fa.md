# example command 
BioSAK cat_fa -i seq_dir -x fa -o combined_seqs.fa

# combine sequence files in a folder after prefixing
# sequence ids with corresponding file name.

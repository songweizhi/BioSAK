BioSAK fa2id -i gnm.fa -o ctg_id.txt
BioSAK fa2id -i reads.fastq -o reads_id.txt -fq

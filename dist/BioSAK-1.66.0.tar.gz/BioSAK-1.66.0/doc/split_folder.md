    BioSAK split_folder -in downloaded_genomes -x fasta -n 10

    BioSAK usearch_uc -uc uclust_0.6.uc -o uclust_0.6_min1.txt
    BioSAK usearch_uc -uc uclust_0.6.uc -o uclust_0.6_min3.txt -n 3

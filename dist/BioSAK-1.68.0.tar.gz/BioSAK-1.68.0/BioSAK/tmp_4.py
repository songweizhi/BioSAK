

demo_line = '\t1\t2\t3\t4'
demo_line_split = demo_line.strip().split('\t')
print(demo_line_split)
col_name_list = demo_line_split[1:]
print(col_name_list)

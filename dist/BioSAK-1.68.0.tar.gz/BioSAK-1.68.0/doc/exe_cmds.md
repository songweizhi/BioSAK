    

    BioSAK exe_cmds -c cmds.txt -t 12

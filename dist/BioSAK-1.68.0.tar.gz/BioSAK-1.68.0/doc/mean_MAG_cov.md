
# Example command
BioSAK mean_MAG_cov -d ctg_lt2500_depth.txt -b bin_folder -x fasta

Format of contig depth file: tab separated, no header!!!
ctg_1   8
ctg_2   26.1

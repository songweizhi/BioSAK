
BioSAK merge_seq -1 ctgs1.fa -2 ctgs2.fa -o combined_ctgs.fa -sl
BioSAK merge_seq -1 reads1.fq -2 reads2.fq -o combined_reads.fq -fq

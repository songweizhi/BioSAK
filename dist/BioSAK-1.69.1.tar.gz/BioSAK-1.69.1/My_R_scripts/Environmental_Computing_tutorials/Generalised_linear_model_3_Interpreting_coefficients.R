# Interpreting coefficients in glms
# http://environmentalcomputing.net/interpreting-coefficients-in-glms/
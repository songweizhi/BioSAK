
# Example commands
    BioSAK get_genome_GTDB -id genome.txt -path genome_paths.tsv -dir release202/fastani -out op_gnm_folder

# -dir: the folder which hold genome_paths.tsv
# genome paths: in the fastani folder from GTDB auxillary_files
# example of genome id file (one id per line):
GCA_902608175.1
GCA_903901015.1
GCF_000007225.1

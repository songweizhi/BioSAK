
BioSAK slice_seq -in idba.fa -id ctg_01 -range 20-400 -out ctg1_20_400bp.fa
BioSAK slice_seq -in idba.fa -id ctg_01 -range 1-50 -out ctg1_1_50bp.fa -rc
BioSAK slice_seq -in idba.fa -id ctg_01 -range 30-end -out ctg1_30bp_to_end.fa

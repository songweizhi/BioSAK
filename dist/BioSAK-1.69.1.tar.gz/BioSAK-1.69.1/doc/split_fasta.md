    BioSAK split_fasta -i input.fa -o output_dir
    BioSAK split_fasta -i input.fa -o output_dir -ns 200
    BioSAK split_fasta -i input.fa -o output_dir -nf 10

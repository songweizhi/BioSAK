
# https://www.datanovia.com/en/blog/top-r-color-palettes-to-know-for-great-data-visualization/

rainbow(20)

heat.colors(20)

terrain.colors(50)

topo.colors(20)

cm.colors(30)


color_selected = sample(terrain.colors(50), 1)



    BioSAK RunGraphMB -gfa assembly_graph.gfa -o output_dir

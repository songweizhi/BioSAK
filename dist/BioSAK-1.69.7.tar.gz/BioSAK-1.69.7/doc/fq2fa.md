
BioSAK fq2fa -i reads_R1.fq -o reads_R1.fa
BioSAK fq2fa -i reads_R2.fq -o reads_R2.fa

BioSAK js_cmds -p Demo -cmd cmds.txt -hd js_header.txt -n 3 -force

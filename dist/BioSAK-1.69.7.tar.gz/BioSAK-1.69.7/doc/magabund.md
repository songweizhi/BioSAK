# example command 

    BioSAK magabund -s all_bins.sam -m all_bins -x fa -o output.txt

# Note
The input sam file is obtained by mapping quality-filtered reads to the assemblies 
derived from these reads. 

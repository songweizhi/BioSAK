
import random

num_list = [0,1,2,3,4,5,6,7,8,9]
num_list_randomized = random.sample(num_list, len(num_list))
print(num_list_randomized)


    
    BioSAK BestHit -i blast_result.tab -o blast_result_BestHit.tab

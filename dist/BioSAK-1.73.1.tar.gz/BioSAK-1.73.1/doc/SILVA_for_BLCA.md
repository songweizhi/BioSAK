    
    BioSAK SILVA_for_BLCA -SILVA_ssu SILVA_138_SSURef_NR99_tax_silva.fasta

# output_file:
SILVA_138_SSURef_NR99_tax_silva_BLCAparsed.fasta
SILVA_138_SSURef_NR99_tax_silva_BLCAparsed.taxonomy

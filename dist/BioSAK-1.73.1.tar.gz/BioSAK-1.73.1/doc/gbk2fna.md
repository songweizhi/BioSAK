BioSAK gbk2fna -i MAG.gbk -o MAG.fna
BioSAK gbk2fna -i gbk_dir -o fna_dir -t 6

BioSAK rename_reads_for_Reago -in Soil_R1.fasta -out Soil_R1_renamed.fasta -p Soil -d 1
BioSAK rename_reads_for_Reago -in Soil_R2.fasta -out Soil_R2_renamed.fasta -p Soil -d 2

# Note
1. The order of paired reads in the two paired reads files must be the same.
2. Prefix of renamed reads (-p) for the two paired reads files must be the same.

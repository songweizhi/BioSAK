
Here are some of my frequently used functions
---

+ [sep_path_name_ext](sep_path_name_ext.py)
+ [number](number.py)
+ [list_and_dict](list_and_dict.py.py)
+ [get file/folder list](file_and_folder.py)
+ [check_executables](check_executables.py)
+ [multiprocessing](multiprocessing.py)
+ [argparse](argparse.py)
+ [index columns](index_columns.py)
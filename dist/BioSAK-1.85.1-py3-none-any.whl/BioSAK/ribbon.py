
# Make ribbon diagrams of conserved linkages between genomes
# https://github.com/conchoecia/odp

'''

Step 1: get the .rbh file





'''






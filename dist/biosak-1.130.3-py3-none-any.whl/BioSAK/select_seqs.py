import argparse
from Bio import SeqIO
from datetime import datetime
from BioSAK.global_functions import time_format


select_seqs_usage = '''
========================= select_seqs example commands =========================

BioSAK select_seqs -i input.fa -id seq_id.txt -o output.fa
BioSAK select_seqs -i input.fa -id seq_id.txt -o output.fa -e

# ID file format (one id per line): 
seq_1
seq_2 COI gene
>seq_3 16S rRNA gene

================================================================================
'''

def select_seqs(args):

    # read in argument
    seq_file        = args['i']
    id_file         = args['id']
    output_file     = args['o']
    exclude_seqs    = args['e']
    in_fastq        = args['fq']

    one_line = True

    # get provided id list
    print(datetime.now().strftime(time_format) + 'Read in sequence id in %s' % id_file)
    seq_id_list = set()
    for seq_id in open(id_file):
        seq_id_list.add(seq_id.strip().split()[0].replace('>', ''))

    seq_in_format = 'fasta'
    if in_fastq is True:
        seq_in_format = 'fastq'

    # report
    if exclude_seqs is False:
        print(datetime.now().strftime(time_format) + 'Extracting sequences in %s' % id_file)
    else:
        print(datetime.now().strftime(time_format) + 'Extracting sequences except those in %s' % id_file)

    # extract sequences
    output_file_handle = open(output_file, 'w')
    for seq_record in SeqIO.parse(seq_file, seq_in_format):
        seq_id = seq_record.id
        if exclude_seqs is False:
            if seq_id in seq_id_list:
                if in_fastq is False:
                    SeqIO.write(seq_record, output_file_handle, 'fasta-2line')
                else:
                    SeqIO.write(seq_record, output_file_handle, 'fastq')

        else:
            if seq_id not in seq_id_list:
                if in_fastq is False:
                    SeqIO.write(seq_record, output_file_handle, 'fasta-2line')
                else:
                    SeqIO.write(seq_record, output_file_handle, 'fastq')

    output_file_handle.close()

    print(datetime.now().strftime(time_format) + 'Sequences exported to %s' % output_file)
    print(datetime.now().strftime(time_format) + 'Done!')


if __name__ == '__main__':

    select_seqs_parser = argparse.ArgumentParser(usage=select_seqs_usage)
    select_seqs_parser.add_argument('-i',    required=True,                          help='fasta file')
    select_seqs_parser.add_argument('-id',   required=True,                          help='sequence id,one id per line')
    select_seqs_parser.add_argument('-o',    required=True,                          help='output file')
    select_seqs_parser.add_argument('-e',    required=False, action="store_true",    help='specify to extract sequences except those in -id')
    select_seqs_parser.add_argument('-fq',   required=False, action="store_true",    help='in fastq format, default: fa')
    args = vars(select_seqs_parser.parse_args())
    select_seqs(args)
